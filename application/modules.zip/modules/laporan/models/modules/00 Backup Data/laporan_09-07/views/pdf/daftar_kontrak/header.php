


<div class="logo">
  <!-- <img src="<?php // echo base_url() ?>assets/sbe/image/logo.png" > -->
</div>
<div class="skpd">
  <center>
    <div class="kop">
      <div class="pemprov_sumbar"><b><?php echo $identitas['identitas'] ?></b></div>
      <div class="nama_instansi"><?php echo $nama_instansi ?> </div>
      <div class="tahun"><b><?php echo $nama_tahap ?> Tahun Anggaran <?php echo $tahun ?></b></div>


     
    </div>
  </center> 
  </div>
  <div class="clearfix"></div>

<div class="garis_kop1"></div>
<div class="garis_kop2"></div>

<div class="judul_laporan"><?php echo $judul_laporan ?></div>