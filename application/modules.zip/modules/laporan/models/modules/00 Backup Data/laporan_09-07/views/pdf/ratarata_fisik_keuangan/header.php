


<div class="logo">
  <!-- <img src="<?php // echo base_url() ?>assets/sbe/image/logo.png" > -->
</div>
<div class="skpd">
  <center>
    <div class="kop">
      <div class="pemprov_sumbar"><b><?php echo $identitas['identitas'] ?></b></div>
      <div class="nama_instansi"><b><?php echo $periode ?> </b></div>


     
    </div>
  </center> 
  </div>
  <div class="clearfix"></div>

<div class="garis_kop1"></div>
<div class="garis_kop2"></div>
  <div class="judul_laporan" style="margin-top:5px"><?php echo $judul_laporan ?></div> 
