


<!-- <div class="logo">
  <img src="<?php //echo base_url() ?>assets/sbe/image/logo.png" >
</div>
<div class="skpd">
  <center>
    <div class="kop">
      <div class="pemprov_sumbar"><b>PEMERINTAH PROVINSI SUMATERA BARAT</b></div>
      <div class="nama_instansi"><?php //echo $nama_instansi ?> </div>
      <div class="tahun"><b>Tahun Anggaran <?php //echo tahun_anggaran() ?></b></div>


     
    </div>
  </center> 
  </div>
  <div class="clearfix"></div>

<div class="garis_kop1"></div>
<div class="garis_kop2"></div> -->

<h1 class="judul_laporan"><?php echo $judul_laporan ?> <br>PROVINSI <?php echo $provinsi ?> <br><?php echo $kab_kota ?> <br>  <?php echo 'Tahun Anggaran '. tahun_anggaran() ?></h1>