
<div class="copyright" style="float:right" >Powered By IT - Biro Administrasi Pembangunan Tahun 2021</div>
<span class="page" style="text-align:right" >Page {PAGENO}/{nbpg}</span>
<div class="clearfix"></div>
