<?php

/**
 * Author     : Alfikri, M.Kom
 * Created By : Alfikri, M.Kom
 * E-Mail     : alfikri.name@gmail.com
 * No HP      : 081277337405
 * Class      : Rekap_realisasi_total_model.php
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Rekap_realisasi_total_model extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
  }
}
