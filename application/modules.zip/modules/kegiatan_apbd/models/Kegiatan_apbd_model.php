<?php
/**
	* Author     : Alfikri, M.Kom
	* Created By : Alfikri, M.Kom
	* E-Mail     : alfikri.name@gmail.com
	* No HP      : 081277337405
	* Class      : Kegiatan_apbd_model.php
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatan_apbd_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
}