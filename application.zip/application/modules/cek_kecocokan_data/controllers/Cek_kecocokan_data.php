<?php

/**
 * Author     : Alfikri, M.Kom
 * Created By : Alfikri, M.Kom
 * E-Mail     : alfikri.name@gmail.com
 * No HP      : 081277337405
 * Class      : cek_kecocokan_data.php
 */
defined('BASEPATH') or exit('No direct script access allowed');

class Cek_kecocokan_data extends MY_Controller
{
	public function __construct()
	{
		
	}

	public function index()
	{
		echo "	dd";
	}

	
}
