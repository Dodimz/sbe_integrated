<?php
/**
	* Author     : Alfikri, M.Kom
	* Created By : Alfikri, M.Kom
	* E-Mail     : alfikri.name@gmail.com
	* No HP      : 081277337405
*/
?>
<div class="tabs-animation">

    <div class="row">
        <div class="col-lg-12 col-xl-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <div style="float:left">
                        <h5 class="card-title">LAPORAN PEKERJAAN SKPD PROVINSI SUMATERA BARAT TAHUN 2020</h5>
                    </div>
                    <div style="float:right">
                        <a href="#" class="btn btn-info" id="sync_all">Syncronyze All</a>
                        <a href="#" class="btn btn-info" id="laporan_akhir">Laporan Total</a>
                    </div>
                    <div class="clearfix"></div>
                    <hr>    
                     <iframe id="tampil_pdf" src="" width="100%" height="768px"></iframe>
                </div>
            </div>
        </div>
    </div>
    <!--  <div class="row">
        <div class="col-lg-12 col-xl-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Total Perhitungan data Program, Kegiatan, Dan Paket / SKPD</h5>
                    <table class="mb-0 table table-hover table-striped table-bordered">
                        <thead style="background:#ebedef; color: black; border-color: red">
                            <tr>
                                <th rowspan="2" style="text-align: center;">No</th>
                                <th rowspan="2" style="text-align: center;">Nama Instansi</th>
                                <th rowspan="2" style="text-align: center;">Pagu Anggaran</th>
                                <th rowspan="2" style="text-align: center;">Jumlah Program</th>
                                <th rowspan="2" style="text-align: center;">Jumlah Kegiatan</th>
                                 <th colspan="3" style="text-align: center;">Jumlah Paket</th>
                              
                            </tr>
                            <tr>
                                <th width="1%">Rutin</th>
                                <th width="1%">Swakelola</th>
                                <th width="1%">Penyedia</th>
                            </tr>
                        </thead>
                        <tbody id="data_jumlah_aktivitas">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> -->
</div>