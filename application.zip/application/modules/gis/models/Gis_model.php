<?php
/**
 * Author     : Alfikri, M.Kom
 * Created By : Alfikri, M.Kom
 * E-Mail     : alfikri.name@gmail.com
 * No HP      : 081277337405
 * Class      : Gis_model.php
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Gis_model extends CI_Model
{
}