<?php
/**
	* Author     : Alfikri, M.Kom
	* Created By : Alfikri, M.Kom
	* E-Mail     : alfikri.name@gmail.com
	* No HP      : 081277337405
*/
?>
<!-- Leaflet -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/leaflet/leaflet.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/leaflet/leaflet.fullscreen.css"/>
<style>
	#mapid{
		height: 500px;
		z-index: 1;
	}
</style>