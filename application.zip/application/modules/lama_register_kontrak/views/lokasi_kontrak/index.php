<?php

/**
 * Author     : Alfikri, M.Kom
 * Created By : Alfikri, M.Kom
 * E-Mail     : alfikri.name@gmail.com
 * No HP      : 081277337405
 */
?>
<!-- <a href="https://www.google.com/maps/search/?api=1&query=-0.7814689359889293,100.3733003602154" class="btn btn-primary btn-sm" id="tracking-btn" target="_blank">Tracking</a> -->
<div class="mb-3 card">
	<div class="card-body">
		<div class="col-md-12">
			  <div class="panel-body" style="width:100%; height:830px" id="googleMap"></div>















		</div>
	</div>
</div>